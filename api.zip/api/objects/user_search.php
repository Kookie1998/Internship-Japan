<?php
class UserSearch{
    // database connection and table name
    private $conn;
    private $table_name = "users";
 
    // object properties
    public $search;

    // constructor
    public function __construct($db){
        $this->conn = $db;
    }
    // check if given email exist in the database
    function search(){
    
        $query = "SELECT * FROM users INNER JOIN user_information ON users.id = user_information.user_id WHERE CONCAT_WS('', country, adres, experience, firstname, lastname) LIKE :search ";
    
        // prepare the query
        $stmt = $this->conn->prepare( $query );
    
        // sanitize
        $this->search=htmlspecialchars(strip_tags($this->search));
        $s = "%".$this->search."%";  

        $stmt->bindParam(':search', $s);
    
    
        // execute the query
        $stmt->execute();
    
        // get number of rows
        $num = $stmt->rowCount();
    
        // if email exists, assign values to object properties for easy access and use for php sessions
        if($num>0){
    
            // get record details / values
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            // return results
            return $rows;
        }
    
        // return false if $row does not exist in the database
        return false;
    }
}