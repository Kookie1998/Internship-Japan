<?php
include_once('../config/core.php');
include_once('../layout/header.php');
include_once('user_search.php');

// get database connection
$database = new Database();
$db = $database->getConnection();

//search object
$user_search = new UserSearch($db);
 
// get posted data
$data = json_decode(file_get_contents("php://input"));


$search= (isset($data->search) ? $data->search : '');

if($search !=''){
    $user_search->search = $search;

    $results = $user_search->search();
    echo json_encode($results);

}else{
 
    // set response code
    http_response_code(401);
 
    // tell the user login failed
    echo json_encode(array("message" => "search failed"));
}
?>