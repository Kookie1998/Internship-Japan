<?php
include_once('../config/core.php');
include_once('../libs/php-jwt-master/src/BeforeValidException.php');
include_once('../libs/php-jwt-master/src/ExpiredException.php');
include_once('../libs/php-jwt-master/src/SignatureInvalidException.php');
include_once('../libs/php-jwt-master/src/JWT.php');
use \Firebase\JWT\JWT;
// include_once('../layout/header.php');

// $query = "SELECT * FROM users INNER JOIN user_information ON users.id = user_information.user_id";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "japan";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $jwt = $_GET['jwt'];
  $decoded = JWT::decode($jwt, $key, array('HS256'));


  $stmt = $conn->prepare("SELECT * FROM users INNER JOIN user_information ON users.id = user_information.user_id WHERE users.id = :users_id");
  $stmt->bindParam(':users_id', $decoded->data->id);



  $stmt->execute();
  $array = array();

  // set the resulting array to associative
  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
  while($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $array[]=$result;
}
echo json_encode($array);
} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}
    