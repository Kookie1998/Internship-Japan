import React, {Component} from 'react';
// import SimpleReactFooter from "simple-react-footer";
import './Footer.css';

class Footer extends Component{
   render(){
      return(
        <footer className="footer-distributed">
        </footer>
      )
  }
}

export default Footer;
