import React, {Component} from 'react';
import './css/Register.css';

class Register extends Component {
  constructor(){
    console.log('constructor');
    super();
    this.state={
      firstname:'',
      lastname:'',
      email:'',
      password:''
    }
  }
    Register = () => {
      console.log('register');
        fetch('http://localhost/intership/api/objects/create_user.php', {
          method:"POST",
          body: JSON.stringify(this.state)
        }).then((response)=>{
          response.json().then((result)=>{})
        })
      }
  render(){
    return (
      <div className="container">
        <img className="headerImg" src='https://allgoodtales.com/wp-content/uploads/2018/07/Cherryblossom-feature.jpg' alt="imgHeader"/>
        <div className="Register">
          <div className="registerForm">
          <h2>Register your account.</h2>
          <label>Firstname:</label>
          <input type="text" className="input" placeholder="Enter firstname" onChange={(event)=>{this.setState({firstname:event.target.value})}} />
          <label>Lastname:</label>
          <input type="text" className="input" placeholder="Enter lastname" onChange={(event)=>{this.setState({lastname:event.target.value})}} />
          <label>Email:</label>
          <input type="email" className="input" placeholder="Enter email" onChange={(event)=>{this.setState({email:event.target.value})}} />
          <label>Password:</label>
          <input type="password" className="input" placeholder="Enter password" onChange={(event)=>{this.setState({password:event.target.value})}} />
          <div className="custom-select">
          <label>Role:</label>
            <select>
             <option value="intern">intern</option>
             <option value="educator">educator</option>
             <option value="company">company</option>
            </select>
          </div>
          <button className="btn" onClick={(event)=>{this.Register()}}>Register</button>
        </div>
      </div>
      </div>
    );
  }
}

export default Register;