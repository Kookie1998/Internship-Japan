import React, { Component } from 'react';
import './css/Home.css';
import profileImg from '../img/profileImg.jpg';

class Home extends Component{
 constructor(){
    super();
    this.state={
        search:null,
        data: []
      }
    }
    search(){
        fetch('http://localhost/intership/api/objects/search.php', {
          method:"POST",
          body: JSON.stringify(this.state)
        }).then((response)=>{
          response.json().then((result)=>{
            console.warn("result",result);
            this.setState({
              data: result
            })
          })
        })
      }
    render(){
        return(
            <div className='container'>
                <img className="imgHeader" src='https://allgoodtales.com/wp-content/uploads/2018/07/Cherryblossom-feature.jpg' alt="imgHeader"/>
                <div className='search'>
                    <input type="text" className='searchInput' placeholder="what are you searching for?" onChange={(event)=>{this.setState({search:event.target.value})}}/>
                    <button className='searchBtn' onClick={()=>{this.search()}}>search</button>
                </div>
                {this.state.data.map((object, index) => (
                 <div className="user" key={index}>
                   <img className="profileImg" src={profileImg} alt="profileImg"/>
                    <p className="userInfo">name: {object.firstname} {object.lastname}</p>
                    <p className="userInfo">country: {object.country}</p>
                    <p className="userInfo">experience: {object.experience}</p>
                    <p className="userInfo">description: {object.profile_description}</p>
                 </div>
                ))}
            </div>
        )
    }
}
export default Home;