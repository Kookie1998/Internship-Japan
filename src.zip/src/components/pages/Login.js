import React, {Component} from 'react';
import './css/Login.css';

class Login extends Component {
  constructor(){
    super();
    this.state={
      email:null,
      password:null,
      login:null,
      store:null,
      jwt:null
    }
  }
  componentDidMount(){
    this.storeCollector()
  }
  storeCollector(){
    let store = JSON.parse(localStorage.getItem('login'))
    if(store && store.login && store.jwt){
      this.setState({
        login:true,
        jwt:store.jwt
      })
    }
  }
  login(){
    fetch('http://localhost/intership/api/objects/login.php', {
      method:"POST",
      body: JSON.stringify(this.state)
    }).then((response)=>{
      response.json().then((result)=>{
        console.warn("result",result);
        console.log(result.jwt);
        localStorage.setItem('login', JSON.stringify({
          login:true,
          jwt:result.jwt
        }))
        this.storeCollector()
      })
    })
  }

  logout(){
    let user = JSON.parse(localStorage.getItem('login'))
    console.warn(user);
    console.log(user.jwt);
    var ret = this.parseJwt(user.jwt);
    console.log(ret.data.email);
  }

  parseJwt (token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
};

  post(){
    fetch('http://localhost/intership/api/objects/update_user.php', {
      method:"POST",
      body: JSON.stringify(this.state)
    }).then((response)=>{
      response.json().then((result)=>{
        console.log(result);
        if(result.message === 'Access denied.'){
          localStorage.removeItem('login');
        }
        console.warn("result", result);
        console.log(result.jwt);
        this.storeCollector()
      })
    })
  }
  render(){
    return (
      <div className="container">
        <img className="headerImg" src='https://allgoodtales.com/wp-content/uploads/2018/07/Cherryblossom-feature.jpg' alt="imgHeader"/>
        <div className="Login">
          {
          !this.state.login?
          <div className="loginForm">
          <h2>login to your account.</h2>
          <input type="text" className="input" placeholder="Enter email" onChange={(event)=>{this.setState({email:event.target.value})}} />
          <input type="password" className="input" placeholder="Enter password" onChange={(event)=>{this.setState({password:event.target.value})}} />
          <button className="btnLogin" onClick={()=>{this.login()}}>Login</button>
          </div>
          :
          <div className="updateInfo">
            {/* <h1><button onClick={()=>{this.logout()}}>logout</button></h1> */}
            <h1>Change your information.</h1>
            <label>firstname:</label>
            <textarea onChange={(event)=>this.setState({firstname:event.target.value})}></textarea>
            <label>lastname:</label>
            <textarea onChange={(event)=>this.setState({lastname:event.target.value})}></textarea>
            <label>email:</label>
            <textarea onChange={(event)=>this.setState({email:event.target.value})}></textarea>
            <button className="updateBtn" onClick={()=>{this.post()}}>Post it</button>
          </div>
        }
        </div>
      </div>
    );
  }
}

export default Login;