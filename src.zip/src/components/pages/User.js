import React, { Component } from 'react';
import axios from 'axios';
import './css/user.css';
import profileImg from '../img/profileImg.jpg';

class User extends Component{
    constructor(props) {
        super(props);
        this.state = {
          selectedFile: null,
          data: [],
          jwt: null
        };
      }

      componentDidMount(){
        let user =  JSON.parse(localStorage.getItem('login'))
        console.log(user)
        if(typeof user == "undefined" || user == null){
            console.warn(user);
        } else {
            axios.get('http://localhost/intership/api/objects/profile.php?jwt=' + user.jwt).then(res => 
          { this.setState({
              data: res.data
          }); });

        }
      }

      // On file select (from the pop up)
    onFileChange = event => {
     // Update the state
     this.setState({ selectedFile: event.target.files[0] });
      
    };
      
      // On file upload (click the upload button)
    onFileUpload = () => {
     // Create an object of formData
     const formData = new FormData();
      
      // Update the formData object
     formData.append(
        "myFile",
        this.state.selectedFile,
        this.state.selectedFile.name
    );
      
    // Details of the uploaded file
    console.log(this.state.selectedFile);
      // Request made to the backend api
      // Send formData object
     axios.post("http://localhost/intership/api/objects/img.php", formData);
    };
      
    render() {
      return (
        <div className="profile">
          <img className="headerImg" src='https://allgoodtales.com/wp-content/uploads/2018/07/Cherryblossom-feature.jpg' alt="imgHeader"/>
            <div className="profileDetails">
                <h1>Profile</h1>
                <img className="profileImg" src={profileImg} alt="profileImg"/> 
                <input className="inputImg" type="file" onChange={this.onFileChange} />
                <button className="btnUpload" onClick={this.onFileUpload}>Upload!</button>
            <div>
            {this.state.data.map((result) => {
            return (
              <div className="details">
                  <p className="info">name: {result.firstname} {result.lastname}</p>
                  <p className="info">email: {result.email}</p>
                  <p className="info">phonenumber: {result.phone_nr}</p>
                  <p className="info">experience: {result.experience}</p>
                  <p className="info">description: {result.profile_description}</p>
              </div>
            )
          })}
             </div>
            </div>
        </div>
      );
    }
}
export default User;