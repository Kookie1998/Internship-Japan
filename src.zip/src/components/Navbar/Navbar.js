import React, {Component} from 'react';
import 'font-awesome/css/font-awesome.min.css';
import {Link} from 'react-router-dom';
import logo from './logo.png';
import './Navbar.css';
class Navbar extends Component{
    constructor(){
        super();
        this.state={
          firstname:null,
          login:null,
          store:null,
          jwt:null,
          clicked: false
        }
      }

    handleClick = () => {
        this.setState({ clicked: !this.state.clicked })
    }

componentDidMount(){
    this.checklogin()
}

checklogin(){
    let user = JSON.parse(localStorage.getItem('login'))
    console.log(user)
    if(typeof user == "undefined" || user == null){
        console.warn(user);
    } else {
        var ret = this.parseJwt(user.jwt);
        this.setState({
            firstname:ret.data.firstname,
          })
        console.log(ret.data.firstname);
   
    }
  }

parseJwt (token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
};

    logoutUser(){
        localStorage.clear();
    }

  render(){
      return(
          <nav className="NavbarItems">
              <nav className="Navbar-logo">
                  <img src={logo} alt="navbar-logo"/> 
              </nav>
              <div className="Menu-icon" onClick={this.handleClick}>
                  {/*if it's clicked set the state to bars icon else to burger menu icon*/}
                  <i className={this.state.clicked ? 'fa fa-times' : 'fa fa-bars'}></i>
              </div>
              <ul className={this.state.clicked ? 'nav-menu active' : 'nav-menu'}>
                  <li><Link className="nav-links" to="/">Home</Link></li>
                  {this.state.firstname?
                    <>
                        <li><Link className="nav-links" to="/Account">Profile</Link></li>
                        <li><Link className="nav-links" to="/Login">settings</Link></li>
                        <li onClick={this.logoutUser()}><Link className="nav-links" to="/">Logout</Link></li>
                        <li className="username">logged in: {this.state.firstname}</li>
                    </>
                    :
                    <div className="menu-links">
                        <li><Link className="nav-links" to="/Register">Sign Up</Link></li>
                        <li><Link className="nav-links" to="/Login">Login</Link></li>
                    </div>
                    }
              </ul>
          </nav>
      )
  }
}

export default Navbar;